gcc -pthread main.c SerialManager.c -o serialService
